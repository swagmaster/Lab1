
public class Pair {

	private void helloWorld() {
		System.out.println("Hello World");
	}
	
}
