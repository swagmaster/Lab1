public class PairDriver {

	public static void main(String[] args) {
		
		Pair pair = new Pair();
		
		System.out.print(pair.toString());
	}

}