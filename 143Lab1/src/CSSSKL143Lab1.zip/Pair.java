
public class Pair {

	public void helloWorld() {
		System.out.println("Hello World");
	}
}
